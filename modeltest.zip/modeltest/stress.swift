//
//  stress.swift
//  modeltest
//
//  Created by 野上貴司 on 2016/12/15.
//  Copyright © 2016年 野上貴司. All rights reserved.
//

import UIKit

class stress: NSObject {

}
