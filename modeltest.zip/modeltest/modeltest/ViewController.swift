//
//  ViewController.swift
//  modeltest
//
//  Created by 野上貴司 on 2016/12/13.
//  Copyright © 2016年 野上貴司. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    //タイマー
    
    @IBOutlet weak var timer: UILabel!
    
    @IBAction func start(_ sender: Any) {
        
        var cnt : Float = 0
        
        //for i in 0 ..< 100000 {
        
        cnt += 0.1
        //sleep(1)
        //}
        
        let str = "".appendingFormat("%.1f",cnt)
        
        timer.text = str
        
        
    }
    
    @IBAction func stop(_ sender: Any) {
        //timer.invalidate()
    }
    @IBAction func reset(_ sender: Any) {
        
    }
    
    
    var myLabel : UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: "start()", userInfo: nil,repeats: true)
        
    }
    
        //連打
    

    @IBOutlet weak var result: UILabel!
    @IBAction func tap(_ sender: UIButton) {
        
        var cnt : Int = 0
        
        //for i in 0 ..< 1000 {
        result.text = String(cnt)
        cnt += 1
        
        let tmp = "".appendingFormat("%d",cnt)
        
        result.text = tmp
        //updateCounter(cnt: cnt)
    }
    
    func updateCounter(cnt : Int) {
        result.text = String(cnt)
    }

}



//var timer: Timer!

//override func viewDidLoad() {
//    super.viewDidLoad()

// Do any additional setup after loading the view, typically from a nib.
//}

//override func viewWillAppear(_ animated: Bool) {
//    super.viewWillAppear(true)
//    timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
//    timer.fire()
//}

//override func viewWillDisappear(_ animated: Bool) {
//    super.viewWillDisappear(true)
//    timer.invalidate()
//}

//func update(tm: Timer) {
// do something
//}
//}

/* 写真表示
 
 private func initImageView(){
 //レイアウト
 let image1:UIImage = UIImage(named:"map.jpg")!
 let imageView = UIImageView(image:image1)
 let screenWidth:CGFloat = view.frame.size.width
 let screenHeight:CGFloat = view.frame.size.height
 
 imageView.center = CGPoint(x:screenWidth/2, y:screenHeight/2)
 
 self.view.addSubview(imageView)
 
 }
 override func didReceiveMemoryWarning() {
 super.didReceiveMemoryWarning()
 // Dispose of any resources that can be recreated.
 }
 }
*/
